package exception;

public class WithdrawlException extends Exception {
	
	public WithdrawlException(String s) {
		System.out.println(s);
	}

}


