package ui;
import java.util.*;
import bean.*;
import exception.*;
import service.AccountService;
import ui.Main;

public class AccountData {
	
	Scanner sc=new Scanner(System.in);
	static List al=new ArrayList();
	String withdrawl;
	String deposit;
	String fundtransfer;
	
	public void addCustomer() {
		
		System.out.println("Enter your Name");
		String name=sc.next();
		System.out.println("Enter Mobile Number");
		long mobile=sc.nextLong();
		try {
			if(String.valueOf(mobile).length()==10 && mobile>0) {
				Customer cust=new Customer(name,mobile);
				//sending the customer data to Account Class
				Account acc=new Account(cust);
				AccountService cs=new AccountService();
				cs.storeCustDetails(acc);
				System.out.println("#Account Created#");
				System.out.println("#Account No :"+acc.getAccountNum()); }
			else
				throw new CustomerValidation("Please Enter valid Mobile Number");
		} catch (CustomerValidation e) {
			System.out.println("Please Try Again");
		}
	}
	
	public void showBalance() {
		AccountService accno=new AccountService();
		System.out.println("Enter the Account No");
		int balshow=sc.nextInt();
		accno.showBalance(balshow);
	}
	
	public void deposit() {
		AccountService accdeposit=new AccountService();
		System.out.println("Enter the Account No");
		int acc=sc.nextInt();
		System.out.println("Enter Deposit Balance");
		double amt = sc.nextDouble();
		accdeposit.depositMoney(acc,amt);
		
		deposit="Account Number :"+acc+" "+"Money Deposited :"+amt;
		al.add(deposit);
	}
	
	public void withdrawl() {
		AccountService accserwith=new AccountService();
		HashMap<Integer,Account> hm=accserwith.retrieveCustDetails();
		System.out.println("Enter Account No");
		int accno=sc.nextInt();
		try {
			if(hm.containsKey(accno)) {
				Account temp=hm.get(accno);
				System.out.println("Availabe balance :"+temp.getBalance());
				System.out.println("Enter Withdrawl Balance");
				double withbal=sc.nextDouble();
				accserwith.withdrwalMoney(accno,withbal);
				
				withdrawl="Account Number :"+accno+" "+"Money Withdrawl :"+withbal;
				al.add(withdrawl); }
			else
				throw new AccountException("Invalid Account Number");
		} catch (AccountException e) {
			System.out.println("Try Again");
		}
	}
	
	public void fundtransfer() {
		AccountService accserfund=new AccountService();
		HashMap<Integer,Account> hm=accserfund.retrieveCustDetails();
		System.out.println("Enter the Withdrawl Account");
		int withacc=sc.nextInt();
		try {
			if(hm.containsKey(withacc)) {
				Account temp=hm.get(withacc);
				System.out.println("Availabe balance :"+temp.getBalance());
				System.out.println("Enter the Deposit Account");
				int depoacc=sc.nextInt();
				System.out.println("Enter the Transfer Money");
				double transfermoney=sc.nextDouble();
				accserfund.fundtransfer(withacc,depoacc,transfermoney);
				
				fundtransfer="Money Transfered to Account No:"+depoacc+" "+"from Acoount No"+withacc+"Amount :"+transfermoney;
				al.add(fundtransfer); }
			else
				throw new AccountException("Invalid Account");
		} catch (AccountException e) {
			System.out.println("Try Again");
		}
	}
	
	static int count=1;
	public void printtransaction() {
		Iterator itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println(count+": "+itr.next());
		count++; }
	}
	

}
