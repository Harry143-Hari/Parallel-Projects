package com.bank.service;

import java.util.Scanner;

import com.bank.bean.Account;
import com.bank.bean.Customer;
import com.bank.dao.AccountDao;

public class AccountService implements ServiceInterface {
	
	Scanner sc = new Scanner(System.in);
	AccountDao accDao= new AccountDao();
	
	//Adding Customer
	public void addAccount(Customer cust) {
		accDao.begin();
		accDao.addAccount(cust);
		accDao.commit();
	}
	
	//get Account By AccounNumber
	public Account getAcc(int accNo) {
		accDao.begin();
		Account accBal=accDao.getAcc(accNo);
		accDao.commit();
		return accBal;
	}
	
	//Amount Deposit
	public void deposit(Account acc) {
		accDao.begin();
		accDao.deposit(acc);
		accDao.commit();
	}
	
	//Amount Withdraw
	public void withdrawl(Account acc) {
		accDao.begin();
		accDao.withdrawl(acc);
		accDao.commit();
	}
	
	//fund transfer between two accounts
	public void fundTransfer(Account acc) {
		accDao.begin();
		accDao.update(acc);
		accDao.commit();
	}
}
