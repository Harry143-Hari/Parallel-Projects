package com.bank.service;

import com.bank.bean.Account;
import com.bank.bean.Customer;

public interface ServiceInterface {
	
	public void addAccount(Customer cust);
	
	public Account getAcc(int accNo);
	
	public void deposit(Account acc);
	
	public void withdrawl(Account acc);
	
	public void fundTransfer(Account acc);

}
