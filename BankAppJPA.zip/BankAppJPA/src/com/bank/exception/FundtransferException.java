package com.bank.exception;

public class FundtransferException extends Exception {
	
	public FundtransferException(String s) {
		System.out.println(s);
	}

}
