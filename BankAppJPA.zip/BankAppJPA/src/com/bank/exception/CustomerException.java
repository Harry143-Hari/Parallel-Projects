package com.bank.exception;

public class CustomerException extends Exception {
	
	public CustomerException(String s) {
		System.out.println(s);
	}

}
