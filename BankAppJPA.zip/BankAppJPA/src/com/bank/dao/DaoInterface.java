package com.bank.dao;

import com.bank.bean.Account;
import com.bank.bean.Customer;

public interface DaoInterface {
	
	public void begin();
	
	public void commit();
	
	public void addAccount(Customer cust);
	
	public Account getAcc(int accNo);
	
	public void deposit(Account acc);
	
	public void withdrawl(Account acc);
	
	public void update(Account acc);
	

}
