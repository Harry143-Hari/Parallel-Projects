package com.bank.bean;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="xcustomer")
public class Customer implements Serializable {
	
	
	@Id
	//@GeneratedValue
	int custId;
	static int counter=20;
	String name;
	long mobileNum;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="accountNo")
	Account account;
	
	
	public Customer() {
		this.custId=counter;
		counter++;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(long mobileNum) {
		this.mobileNum = mobileNum;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", mobileNum=" + mobileNum + ", account=" + account
				+ "]";
	}
	
}
